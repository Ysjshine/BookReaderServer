CREATE TRIGGER `OnUpdateReadPosition`
AFTER UPDATE ON `ReadPositions`
FOR EACH ROW
  BEGIN
    UPDATE Books
    SET readTimes = readTimes + 1
    WHERE BookID = new.BookID;
  END