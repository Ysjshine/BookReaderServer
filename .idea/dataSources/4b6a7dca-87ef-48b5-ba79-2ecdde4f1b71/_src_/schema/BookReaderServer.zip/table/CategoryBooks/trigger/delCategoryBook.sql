CREATE TRIGGER `delCategoryBook`
AFTER DELETE ON `CategoryBooks`
FOR EACH ROW
  BEGIN
    DECLARE temp INT;
    SET temp = (SELECT count(*)
                FROM CategoryBooks
                WHERE UserID = old.UserID AND BookID = old.BookID);
    IF (temp = 0)
    THEN
      DELETE FROM ReadPositions
      WHERE UserID = old.UserID AND BookID = old.BookID;
    END IF;
  END