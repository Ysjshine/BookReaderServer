CREATE TRIGGER `OnDelCategoryBook`
AFTER DELETE ON `CategoryBooks`
FOR EACH ROW
  BEGIN
    DECLARE temp INT;
    UPDATE Books SET collectTimes = collectTimes-1 WHERE BookID = old.BookID;
    SET temp = (SELECT count(*)
                FROM CategoryBooks
                WHERE UserID = old.UserID AND BookID = old.BookID);
    IF (temp = 0)
    THEN
      DELETE FROM ReadPositions
      WHERE UserID = old.UserID AND BookID = old.BookID;
    END IF;
  END