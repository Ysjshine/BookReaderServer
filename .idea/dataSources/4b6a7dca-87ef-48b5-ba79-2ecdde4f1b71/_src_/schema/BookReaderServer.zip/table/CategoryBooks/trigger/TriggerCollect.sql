CREATE TRIGGER `TriggerCollect`
AFTER INSERT ON `CategoryBooks`
FOR EACH ROW
  BEGIN
  UPDATE Books SET collectTimes = collectTimes+1 WHERE BookID = new.BookID;
END